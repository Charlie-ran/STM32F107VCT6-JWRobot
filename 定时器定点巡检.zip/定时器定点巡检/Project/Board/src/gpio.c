// coding UTF8


/**
* Copyright (c) 2021 Hefei Xiaobu Technologies Co., LTD. All rights reserved
*/

/*
log:

20230301:   ע��pb0,1;pe6���ų�ʼ�����°���û��ʹ����3�����ţ�
            ����adc���ų�ʼ������pa3,4,5;pb0,1;pc2
*/
 

/**
 GPIO ����ʵ��
 �˲��� ʵ�� xbo mkzgd ������GPIO ����
 
 ���ڰ������棬�Ѿ�ȷ������������ GPIO ���ţ��ڴ�.C �ļ��� init/config �������Ѿ���������á�
*/


#include "stm32f10x.h"
#include "gpio.h"
#include "usart.h"
#include "main.h"

extern Motor_t Motor;
//==================================================================================================
//
// ������ ��̬����
//
//==================================================================================================


static gpio_callback_irq  def_irq_callback = 0;

static uint16_t pulse_cout = 0;

uint8_t Move_End = 0; 
//==================================================================================================
//
// ������ ��̬ ����
//
//==================================================================================================

/*
NVIC���ã��ж����ȼ� ����Ӳ����ʼ����gpio���е���
*/
static void NVIC_Configuration(void) //���ȼ�����ԭ����λ�������ж����ȼ�>����ͳ���ж����ȼ�>��������ж����ȼ�
{
    NVIC_InitTypeDef   NVIC_InitStructure;
    /* Set the Vector Table base location at 0x08000000 */
    NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
   // NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x7800);
    /* 2 bit for pre-emption priority, 2 bits for subpriority */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
/*
    ����ŵı������õ��ж����ȼ�
    ��ʱ��2��3��4�����ж����ȼ����ж������ã�
*/
    /* Enable the Ethernet global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = ETH_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
#if 0
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority= 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;        
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;            
    NVIC_Init(&NVIC_InitStructure);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority =1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
#endif 
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn ;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE ;    
    NVIC_Init(&NVIC_InitStructure); 
#if 0
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE ;    
    NVIC_Init(&NVIC_InitStructure);
    
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn ;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE ;    
    NVIC_Init(&NVIC_InitStructure);
 #endif 
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn ;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE ;    
    NVIC_Init(&NVIC_InitStructure);
}

/*******************************************GPIO��ʼ������************************************/
/*
����ֵ��
   �ɹ������� ��Ӧ�� ָ��
   ʧ�ܣ����� 0
*/
static GPIO_TypeDef* to_impl_group(bd_gpio_group group)
{
    GPIO_TypeDef* GPIOx = 0;

    if(group >= bd_gpio_group_a  && group <= bd_gpio_group_g){
        GPIOx = (GPIO_TypeDef*)(GPIOA_BASE + 0x0400 * (group - 1) );
    }
    return GPIOx;
}


/*
����ֵ��
     �ɹ�  ��Ӧ��  pin ֵ
     ʧ��  ����    0
*/

static uint16_t to_impl_pin(bd_gpio_pin pin)
{
    int pin_int = pin;
    uint16_t ret_pin = 0;
    if(( pin >= bd_gpio_pin_0 ) && (pin <= bd_gpio_pin_15 )){
        ret_pin = (uint16_t)(0x0001 << (pin_int - 1) );
    }
    return ret_pin;

}

static GPIOMode_TypeDef to_impl_mode(bd_gpio_mode mode)
{
    GPIOMode_TypeDef mode_mode = GPIO_Mode_IN_FLOATING;

    switch(mode){
        case bd_gpio_mode_ain:
            mode_mode = GPIO_Mode_AIN;
        break;
        case bd_gpio_mode_in_floating:
            mode_mode = GPIO_Mode_IN_FLOATING;
        break;
        case bd_gpio_mode_ipd:
            mode_mode = GPIO_Mode_IPD;
        break;
        case bd_gpio_mode_ipu:
            mode_mode = GPIO_Mode_IPU;
        break;
        case bd_gpio_mode_out_od:
            mode_mode = GPIO_Mode_Out_OD;
        break;
        case bd_gpio_mode_out_pp:
            mode_mode = GPIO_Mode_Out_PP;
        break;
        case bd_gpio_mode_af_od:
            mode_mode = GPIO_Mode_AF_OD;
        break;
        case bd_gpio_mode_af_pp:
            mode_mode = GPIO_Mode_AF_PP;
        break;
    }
    return mode_mode;

}

static GPIOSpeed_TypeDef to_impl_speed(bd_gpio_speed speed)
{
    GPIOSpeed_TypeDef speed_speed = GPIO_Speed_2MHz;
    switch(speed){
        case bd_gpio_speed_10mhz:
            speed_speed = GPIO_Speed_10MHz;
        break;
        case bd_gpio_speed_2mhz:
            speed_speed = GPIO_Speed_2MHz;
        break;
        case bd_gpio_speed_50mhz:
            speed_speed = GPIO_Speed_50MHz;
        break;
    }
    return speed_speed;
}
/*******************************************GPIO��ʼ������************************************/

/*******************************************�жϳ�ʼ������************************************/
static uint32_t to_impl_exti_line(bd_exti_line line)
{
    int line_int = line;
    uint32_t ret_line = 0;
    if(( line >= bd_exti_line_0 ) && (line <= bd_exti_line_19 )){
        ret_line = (uint32_t)(0x0001 << line_int);
    }
    return ret_line;
}

static EXTIMode_TypeDef to_impl_exti_mode(bd_exti_mode mode)
{
    EXTIMode_TypeDef mode_mode = EXTI_Mode_Interrupt;

    switch(mode){
        case bd_exti_mode_interrupt:
            mode_mode = EXTI_Mode_Interrupt;
        break;
        case bd_exti_mode_event:
            mode_mode = EXTI_Mode_Event;
        break;

    }
    return mode_mode;

}

static EXTITrigger_TypeDef to_impl_exti_trigger(bd_exti_trigger trigger)
{
    EXTITrigger_TypeDef trigger_trigger = EXTI_Trigger_Rising;

    switch(trigger){
        case bd_exti_trigger_rising:
            trigger_trigger = EXTI_Trigger_Rising;
        break;
        case bd_exti_trigger_falling:
            trigger_trigger = EXTI_Trigger_Falling;
        break;
        case bd_exti_trigger_rising_falling:
            trigger_trigger = EXTI_Trigger_Rising_Falling;
        break;

    }
    return trigger_trigger;

}
/*******************************************�ն˳�ʼ������************************************/

//==================================================================================================
//
// ������ �����Ľӿں���
//
//==================================================================================================
void set_gpio_config(bd_gpio_group group,  bd_gpio_pin pin, bd_gpio_mode mode ,bd_gpio_speed speed)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_TypeDef* GPIOx = to_impl_group(group);
    if(GPIOx == 0)
    {
        return ;
    }
    uint16_t pinx = to_impl_pin(pin);
    if(pinx == 0)
    {
        return ;
    }
    GPIOMode_TypeDef modex = to_impl_mode(mode);
    GPIOSpeed_TypeDef speedx = to_impl_speed(speed);

    // todo ת����ķ���ֵ��飬

    GPIO_InitStructure.GPIO_Pin = pinx;
    GPIO_InitStructure.GPIO_Speed = speedx;
    GPIO_InitStructure.GPIO_Mode = modex;    
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}

/*
���õ���GPIO�ڵ�ֵ 0 �͵�ƽ   1 �ߵ�ƽ
*/
void set_gpio_value(bd_gpio_group group, bd_gpio_pin pin, char val )
{
    GPIO_TypeDef* GPIOx = to_impl_group(group);
    uint16_t GPIO_Pinx = to_impl_pin(pin);
    if(val)
    {
        GPIO_SetBits( GPIOx,  GPIO_Pinx);
    }
    else
    {
        GPIO_ResetBits( GPIOx,  GPIO_Pinx);
    }
}


char get_gpio_output_value(bd_gpio_group group, bd_gpio_pin pin )
{
    GPIO_TypeDef* GPIOx = to_impl_group(group);
    uint16_t GPIO_Pinx = to_impl_pin(pin);

    return GPIO_ReadOutputDataBit( GPIOx,  GPIO_Pinx);
}

char get_gpio_input_value(bd_gpio_group group, bd_gpio_pin pin )
{
    GPIO_TypeDef* GPIOx = to_impl_group(group);
    uint16_t GPIO_Pinx = to_impl_pin(pin);

    return GPIO_ReadInputDataBit( GPIOx,  GPIO_Pinx);
}

void set_exti_config(bd_exti_line line ,bd_exti_mode mode ,bd_exti_trigger tigger)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    uint32_t linex = to_impl_exti_line(line);
    if(0 == linex)
    {
        return ;
    }
    EXTIMode_TypeDef modex = to_impl_exti_mode(mode);
    EXTITrigger_TypeDef tifferx = to_impl_exti_trigger(tigger);
    
    EXTI_InitStructure.EXTI_Line = linex; 
    EXTI_InitStructure.EXTI_Mode = modex;
    EXTI_InitStructure.EXTI_Trigger = tifferx;
    EXTI_InitStructure.EXTI_LineCmd    = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}


/*
 GPIO ����ʵ��
 �˲��� ʵ�� xbo mkzgd ������GPIO ����
 ���ڰ������棬�Ѿ�ȷ������������ GPIO ���ţ��ڴ�.C �ļ��� init/config �������Ѿ���������á�
*/
void gpio_config(void)
{
    //stm32��ETH���������AHB1�����ϣ�λ��RCC_AHB1ENR��bit25-bit27
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ETH_MAC | RCC_AHBPeriph_ETH_MAC_Tx |RCC_AHBPeriph_ETH_MAC_Rx, ENABLE);
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_USART1 
                            |RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO, ENABLE);
    
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_USART2,  ENABLE);
    //�ܽ���ӳ��
    GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);
    GPIO_PinRemapConfig( GPIO_Remap_USART2,  ENABLE);
    
    NVIC_Configuration();



/*
    ���������ã�   
                PE12  ->  ���DIR
                PB11  ->  ���ENA
                Pa0  ->  ���PULSE
	            
*/
    set_gpio_config(bd_gpio_group_e,bd_gpio_pin_12,bd_gpio_mode_out_pp,bd_gpio_speed_50mhz);
    set_gpio_config(bd_gpio_group_b,bd_gpio_pin_11,bd_gpio_mode_out_pp,bd_gpio_speed_50mhz);
    set_gpio_config(bd_gpio_group_a,bd_gpio_pin_0,bd_gpio_mode_out_pp,bd_gpio_speed_50mhz);
/*
    LED���ã�   
                PE3  ->  LED2
                PE4  ->  LED3	            
*/	
    set_gpio_config(bd_gpio_group_e,bd_gpio_pin_3,bd_gpio_mode_out_pp,bd_gpio_speed_50mhz);
    set_gpio_config(bd_gpio_group_e,bd_gpio_pin_4,bd_gpio_mode_out_pp,bd_gpio_speed_50mhz);
		set_gpio_value(bd_gpio_group_e,bd_gpio_pin_4,1);
		set_gpio_value(bd_gpio_group_e,bd_gpio_pin_3,1);
		
		
		
		/*
�����ж����ã�      
                    PC13 ->  ˮƽ��λ�ӽ�����
                    PC14 ->  ˮƽ��λ�ӽ�����

*/		
		set_gpio_config(bd_gpio_group_c,bd_gpio_pin_13,bd_gpio_mode_ipu,bd_gpio_speed_50mhz);
    GPIO_EXTILineConfig( GPIO_PortSourceGPIOC,  GPIO_PinSource13);
    set_exti_config(bd_exti_line_13, bd_exti_mode_interrupt,bd_exti_trigger_falling);
    
    set_gpio_config(bd_gpio_group_c,bd_gpio_pin_14,bd_gpio_mode_ipu,bd_gpio_speed_50mhz);
    GPIO_EXTILineConfig( GPIO_PortSourceGPIOC,  GPIO_PinSource14);
    set_exti_config(bd_exti_line_14, bd_exti_mode_interrupt,bd_exti_trigger_falling);
}


void exti_forward_handle(Motor_t * motor_control_obj)
{
	if( (0 == get_gpio_input_value(FORWARD_LIMIT_GROUP,FORWARD_LIMIT_PIN))&&
			(0 == motor_control_obj->forward_limit_flag))
	{
			motor_control_obj->forward_limit_flag = 1;
		  MOTOR_EN(1);
	}
	if( (1 == motor_control_obj->forward_limit_flag ) && (1 == get_gpio_input_value(FORWARD_LIMIT_GROUP,FORWARD_LIMIT_PIN)) )
	{
			motor_control_obj->forward_limit_flag = 0;
	}
}

 void exti_backward_handle(Motor_t * motor_control_obj)
 {
	 if( (0 == get_gpio_input_value(BACKWARD_LIMIT_GROUP,BACKWARD_LIMIT_PIN) ) &&
			(0 == motor_control_obj->backward_limit_flag ) )
	{
			motor_control_obj->backward_limit_flag = 1;
		  MOTOR_EN(1);
	}
	if( (1 == motor_control_obj->backward_limit_flag ) && 
			(1 == get_gpio_input_value(BACKWARD_LIMIT_GROUP,BACKWARD_LIMIT_PIN) ) )
	{
			motor_control_obj->backward_limit_flag = 0;	
	}
 }

void EXTI15_10_IRQHandler()
{
    if(EXTI_GetITStatus(EXTI_Line13)!= RESET){
				MOTOR_EN(1);
				Move_End = 1; 
				exti_forward_handle(&Motor);
				
        EXTI_ClearITPendingBit(EXTI_Line13);
    }
    
    if(EXTI_GetITStatus(EXTI_Line14)!= RESET){
				MOTOR_EN(1);
				Move_End = 1; 
				exti_backward_handle(&Motor);
				
        EXTI_ClearITPendingBit(EXTI_Line14);
    }
}


