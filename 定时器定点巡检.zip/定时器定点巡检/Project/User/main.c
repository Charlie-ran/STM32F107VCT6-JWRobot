
/**
* Copyright (c) 2021 Hefei Xiaobu Technologies Co., LTD. All rights reserved
*/
#include "stm32f10x.h"
#include <system_stm32f10x.h>
#include <stdio.h> 
#include <stdint.h>
#include "timer.h"
#include "app_func.h"
Motor_t Motor;//电机控制结构体
#define DEBOUNCE_COUNT 3  // 连续3次确认才动作
#define safe_distance 100//安全距离阈值
uint8_t Move_Stop=0;
uint8_t menual_stop=0;
uint8_t showcmd = 0;
uint16_t detect_distance=0;//检测距离变量
uint16_t detect_flag=0;//检测标志位
int main(void)
{
    SystemInit();//系统初始化
    gpio_config(); //gpio初始化
    sys_tick_init(SYS_FREQ);//计时初始化
    USART3_Init(UART3_BAUD);//初始化串口3 115200
    USART1_RS485_Init(UART1_BAUD);//初始化485usart1 9600
    MOTOR_EN(ENA);//使能电机引脚
    OLED_Init();//初始化OLED屏
    OLED_Clear(); //清除显示内容
    Motor_Init();//电机控制结构体初始化
    TIM5_PWM_Init(999,71);//初始化TIM5 PWM    
    /*-------------------------------------
    以上为全部外设初始化代码
    --------------------------------------*/
    printf("system init completed\n");//打印到串口3
    oledInitprint();//OLED显示初始化内容
    showLOGO();//展示青鸟图标 
    uint16_t dist = 0;//超声波数据存放变量
    uint16_t temp = 0;//温度数据存放变量
    uint8_t DETECT_POINT=DETECT_POINT1;
    float point1_data[256];
    float point2_data[256];
    float point3_data[256];
    
    uint8_t oldshowcmd  = showcmd;//OLED显示状态标志上一个状态值
    uint16_t danger_count;   //三次确认防抖
    delay_ms(500);
	Motor_Start(&Motor);//启动电机
    uint32_t point1_index=0;
    uint32_t point2_index=0;
    uint32_t point3_index=0;
    while(1)
    {
        Motor_Speed(15000);//设置电机速度为18000
        //电机状态监测，超声波检测，OLED显示
        Moter_Check_Status(&Motor);//监测电机状态，执行相应操作

        choose_detect_point(DETECT_POINT);//选择检测点
        if(Motor.Motor_Dir == FORWARD)
        {
            //如果电机脉冲计数大于等于检测距离且检测标志位为0，则说明电机到达目标位置
            if(Motor.Pulse_Count >= detect_distance && detect_flag>1)
            {
                Motor_Stop();
                if (DETECT_POINT==DETECT_POINT1)
                {
                    point1_data[point1_index++]=(float)temp/10.0;
                    for (int i = 0; i < point1_index; i++)
                    {
                        printf("temp_1=%.1f ",point1_data[i]);
                    }
                    printf("\n");
                }
                if (DETECT_POINT==DETECT_POINT2)
                {
                    point2_data[point2_index++]=(float)temp/10.0;
                    for (int i = 0; i < point2_index; i++)
                    {
                        printf("temp_2=%.1f ",point2_data[i]);
                    }
                    printf("\n");
                }
                if (DETECT_POINT==DETECT_POINT3)
                {
                    point3_data[point3_index++]=(float)temp/10.0;
                    for (int i = 0; i < point3_index; i++)
                    {
                        printf("temp_3=%.1f ",point3_data[i]);
                    }
                    printf("\n");
                }

                showFRAME();
                printnum2OLEDln("dist", dist);
                printnum2OLEDln("temp", temp);
                oldshowcmd = OLED_DATA;

                delay_ms(1500);
                Motor_Resume();
                showcmd = OLED_LOGO;
                detect_flag=1;
            }
        }else if(Motor.Motor_Dir == BACKWARD)
        {
            if(Motor.Pulse_Count >= (Motor.Pulse_Max-detect_distance) && detect_flag>1)
            {
                Motor_Stop();
            if (DETECT_POINT==DETECT_POINT1)
            {
                point1_data[point1_index++]=(float)temp/10.0;
                for (int i = 0; i < point1_index; i++)
                {
                    printf("temp_1=%.1f ",point1_data[i]);
                }
                printf("\n");
            }
            if (DETECT_POINT==DETECT_POINT2)
            {
                point2_data[point2_index++]=(float)temp/10.0;
                for (int i = 0; i < point2_index; i++)
                {
                    printf("temp_2=%.1f ",point2_data[i]);
                }
                printf("\n");
            }
            if (DETECT_POINT==DETECT_POINT3)
            {
                point3_data[point3_index++]=(float)temp/10.0;
                for (int i = 0; i < point3_index; i++)
                {
                    printf("temp_3=%.1f ",point3_data[i]);
                }
                printf("\n");
            }                
                
                showFRAME();
                printnum2OLEDln("dist", dist);
                printnum2OLEDln("temp", temp);
                oldshowcmd = OLED_DATA;

                delay_ms(1500);
                Motor_Resume();
                showcmd = OLED_LOGO;
                detect_flag=1;
            }
        }


        if (getUART3data())//如果有串口数据接收则处理串口数据，改变OLED显示状态
        {
            if (strcmp("POINT1",USART3_RxBuffer)==0)
            {
                DETECT_POINT=DETECT_POINT1;

            }
            else if (strcmp("POINT2",USART3_RxBuffer)==0)
            {
                DETECT_POINT=DETECT_POINT2;
            }
            else if(strcmp("POINT3",USART3_RxBuffer)==0)
            {
                DETECT_POINT=DETECT_POINT3;
            }
            if (strcmp("MENU",USART3_RxBuffer)==0)
            {
                showcmd=OLED_MENU;//如果接收数据是MENU则切换到菜单界面
            }
            if(oldshowcmd==OLED_MENU)//如果当前显示状态是菜单界面，则根据接收数据改变显示状态
            {
                //根据接收数据改变显示状态
                if (strcmp("DATA",USART3_RxBuffer)==0)
                {
                    showcmd = OLED_DATA;
                }
                else if (strcmp("LOGO",USART3_RxBuffer)==0)
                {
                    showcmd = OLED_LOGO;
                }
                else if (strcmp("CTRL",USART3_RxBuffer)==0)
                {
                    showcmd = OLED_CTRL;
                }
            }
            if(oldshowcmd==OLED_DATA||oldshowcmd==OLED_LOGO)//如果当前显示状态是数据界面，则根据接收数据返回菜单
            {
                if (strcmp("BACK",USART3_RxBuffer)==0)
                {
                    showcmd = OLED_MENU;
                }
            }
            if(oldshowcmd==OLED_CTRL)//如果当前显示状态是控制界面，则根据接收数据执行相应的控制命令
            {
                if (strcmp("STOP",USART3_RxBuffer)==0)
                {
                    Motor_Stop();
                    Moter_Set_Manual_Stop();//设置手动停止标志，防止自动恢复
                }
                else if (strcmp("RESUME",USART3_RxBuffer)==0)
                {
                    Moter_Set_Manual_Resume();//取消手动停止标志，允许自动恢复
                    Motor_Resume();
                }
                else if (strcmp("BACK",USART3_RxBuffer)==0)
                {
                    showcmd = OLED_MENU;
                }
            }
            memset(USART3_RxBuffer, 0, USART3_RX_BUFFER_SIZE);//清空接收缓冲区
        }

        Stop_Blink(1);
        if(fmeCnt%2==0)
        {
            temp = get_tempture();          //100 ms
        }else
            dist = get_distence();          //100 ms
        
        // //如果检测到障碍物在安全距离内，则先停下来，等待100ms后再次检测，如果连续三次检测到障碍物都在安全距离内，则继续前进，否则继续停在原地
        // if (dist<=safe_distance)
        // {
        //     Motor_Stop();
        // }
        // //等待100ms后再次检测
        // for(danger_count=0;danger_count<DEBOUNCE_COUNT;danger_count++)
        // {
        //     dist = get_distence();    //100 ms
        //     if (dist>safe_distance)
        //     {
        //         delay_ms(10);
        //     }
        //     else
        //     {
        //         break;
        //     }
        // }
        // //如果连续三次检测到障碍物都在安全距离内，则继续前进，否则继续停在原地
        // if (danger_count==3)
        // {
        //     Motor_Resume();//三次确认之后继续前进
        // }   
        //OLED显示控制
        switch (showcmd)
        {
            case OLED_DATA:
            //如果显示状态改变则刷新显示框架
            if (oldshowcmd != showcmd)
            {
                showFRAME();
            }
            //显示数据
            printnum2OLEDln("dist", dist);
            printnum2OLEDln("temp", temp);
            //更新显示状态标志
            oldshowcmd = showcmd;
            break;
            case OLED_MENU:
            if (oldshowcmd != showcmd)            {
                showMENU();
            }
            oldshowcmd = showcmd;
            break;
            case OLED_LOGO:
            if (oldshowcmd != showcmd)            {
                showLOGO();
            }
            oldshowcmd = showcmd;
            break;
            case OLED_CTRL:
            if (oldshowcmd != showcmd)            {
                showCTRL();
            }
            oldshowcmd = showcmd;
            break;
            default:
            break;
        }
        
        fmeCnt++;
        if(fmeCnt > 10){
            fmeCnt = fmeCnt % 11 + 1;
        }
    }
}
//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               佛祖保佑         永无BUG
//
//
//