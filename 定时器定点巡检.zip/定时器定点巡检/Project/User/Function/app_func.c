#include "app_func.h"
#include "bmp.h"
/*************************************************************************
电机控制
*************************************************************************/
/*----------------------------------------------------------
stopThre         超声波检测停止距离阈值
resume_flag      超声波检测消抖
-----------------------------------------------------------*/
uint8_t stopThre = 100;
static uint8_t resume_flag = 0;
uint16_t fmeCnt = 1;//循环计数变量
extern uint16_t detect_flag;
extern uint16_t detect_distance;//检测距离变量
/*----------------------------------------------------------
函数描述： 设置电机运动方向
输入参数：
类型： Motor_Dir_e {FORWARD 向前、 BACKWARD 向后}
返回值： void
-----------------------------------------------------------*/
void MOTOR_Dir(Motor_Dir_e val)  //电机方向
{
    set_gpio_value(bd_gpio_group_e,bd_gpio_pin_12,val);
}
/*----------------------------------------------------------
函数描述： 设置电机使能
输入参数： 类型： Motor_En_e {ENA 使能、 DIS 停止}
返回值： void
-----------------------------------------------------------*/
void MOTOR_EN(Motor_En_e val)  //电机使能
{ 
    set_gpio_value(bd_gpio_group_b,bd_gpio_pin_11,val);
}
/*----------------------------------------------------------
函数描述： 初始化电机
输入参数： 类型： void
返回值： void
-----------------------------------------------------------*/
void Motor_Init(void)
{
    if(get_gpio_input_value(bd_gpio_group_c, bd_gpio_pin_14) == 1){
        Motor.Motor_Dir = FORWARD;
    } else {
        Motor.Motor_Dir = BACKWARD;
    }
    Motor.Motor_En = ENA;
    Motor.Pulse_Count = 0;
    Motor.Speed = MAX_SPEED;
    Motor.Pulse_Max = PULSE_NUM;
    Motor.Motor_Flag = 0; 
    TIM5_PWM_Init(TIM5_ARR, TIM5_PSC);
}
/*----------------------------------------------------------
函数描述： 设置电机速度
输入参数： 类型： uint16_t speed（速度值）
返回值： void
-----------------------------------------------------------*/
void Motor_Speed(uint16_t speed)
{
    TIM_SetCompare1(TIM5, (TIM_AFTER_PRESCALER_FRENQ>>1)/speed);//
    TIM_SetAutoreload(TIM5,TIM_AFTER_PRESCALER_FRENQ/speed - 1);//
}
/*----------------------------------------------------------
函数描述： 电机开始运行
输入参数： 类型： Motor_t *Motor（电机控制结构体）
返回值： void
-----------------------------------------------------------*/
void Motor_Start(Motor_t *Motor)
{
    MOTOR_Dir(Motor->Motor_Dir);
    MOTOR_EN(Motor->Motor_En);
    Motor_Speed(Motor->Speed);
    TIM_Cmd(TIM5, ENABLE);
    Move_Stop = 0;
}
/*----------------------------------------------------------
函数描述： 设置电机方向
输入参数：
    类型： Motor_Dir_e {FORWARD 向前、 BACKWARD 向后}
    类型： Motor_t *Motor（电机控制结构体）
返回值： void
-----------------------------------------------------------*/
void Motot_Set_Dir(Motor_Dir_e val, Motor_t *Motor){
    Motor->Motor_Dir = val;
}
/*----------------------------------------------------------
函数描述： 反转电机方向
输入参数：类型： Motor_t *Motor（电机控制结构体）
返回值： void
-----------------------------------------------------------*/
void Motor_Change_Dir(Motor_t *Motor)
{
    if(Motor->Motor_Dir == FORWARD){
        Motot_Set_Dir(BACKWARD, Motor);
    }else{
        Motot_Set_Dir(FORWARD, Motor);
    }
}
/*----------------------------------------------------------
函数描述： 停止电机运行
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Motor_Stop(){
    TIM_Cmd(TIM5, DISABLE);
    Move_Stop = 1;
}
/*----------------------------------------------------------
函数描述： 恢复电机运行
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Motor_Resume(){
    TIM_Cmd(TIM5, ENABLE);
    Move_Stop = 0;
}

void Moter_Set_Manual_Stop()
{ 
    menual_stop = 1;
}
void Moter_Set_Manual_Resume()
{ 
    menual_stop = 0;
}
/*----------------------------------------------------------
函数描述： 停止电机运行
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void choose_detect_point(uint8_t point){
    if(point == DETECT_POINT1){
        detect_distance=Motor.Pulse_Max/2;
    }else if(point == DETECT_POINT2){
        detect_distance=Motor.Pulse_Max/4;
    }else if(point == DETECT_POINT3){
        detect_distance=Motor.Pulse_Max*3/4;
    }
}
/*----------------------------------------------------------
函数描述： 校验电机状态，超声波检测停止
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Moter_Check_Status(Motor_t *Motor)
{
    if(Move_End == 1){
        Motor->Pulse_Max=Motor->Pulse_Count;
        Move_End = 0;
        detect_flag++;
        Motor->Pulse_Count = 0;
        Motor_Change_Dir(Motor);//改变电机方向
        Motor->Motor_En = ENA;//电机状态改为使能
        Motor_Start(Motor);//电机重新开始工作
    }
/*
    if(get_gpio_input_value(bd_gpio_group_c, bd_gpio_pin_14) == 0){
        Motor->Motor_Dir = FORWARD;
    } 
    if(get_gpio_input_value(bd_gpio_group_c, bd_gpio_pin_13) == 0){
        Motor->Motor_Dir = BACKWARD;
    }
*/
    if(RADAR_RX_DIST != 0 && RADAR_RX_DIST <= stopThre){
        Motor_Stop();
        resume_flag = 0;//重置消抖计数
    }else if(Move_Stop == 1 && menual_stop==0){
        resume_flag++;
        if(resume_flag > 2){
            resume_flag = 0;
            Motor_Resume();
        }
    }
}
/*************************************************************************
OLED控制
*************************************************************************/
/*----------------------------------------------------------
uint8_t linenum      希望oled显示内容所在的行数
char showstr[17]     存放oled输出内容，一行16个非中文字符
char shownumstr[17]  用来拼接需要显示数据的内容
uint8_t showstatus   标识是否处于显示logo的状态 0 不是 1 是
-----------------------------------------------------------*/
static uint8_t linenum = 0;
char showstr[17];
char shownumstr[17];
static uint8_t showstatus = 0;
/*----------------------------------------------------------
函数描述： 输送到oled显示字符，再次调用会自动显示换行
输入参数：类型： char* str （要显示的字符，只显示16个，超过内容不显示）
返回值： void
-----------------------------------------------------------*/
void print2OLEDln(const char* str)
{
    if(showstatus == 1){
        OLED_Clear();
        showstatus = 0;
    } else {
        for(int i = 0; i < 16; i++){
            showstr[i] = ' ';
        }
    }
    OLED_ShowString(0, linenum * 2, showstr, 16);
    memcpy(showstr, str, 16);
    OLED_ShowString(0, linenum * 2, showstr, 16);
    linenum++;
    linenum = linenum % 4;
}
/*----------------------------------------------------------
函数描述： 输送到oled显示字符，后接数据，再次调用会自动显示换行，
          居住中显示，只显示在第二第三行
输入参数：
    类型： char* str （要显示的字符串）
    类型： uint16_t num （要显示的数字，与字符串一共只显示16个，超过内容不显示）
返回值： void
-----------------------------------------------------------*/
void printnum2OLEDln(const char* str, uint16_t num)
{
    if(linenum == 0 || linenum == 3){
        linenum = 1;
    }
    if(showstatus == 1){
        OLED_Clear();
        showstatus = 0;
    } else {
        for(int i = 0; i < 16; i++){
            shownumstr[i] = ' ';
        }
    }
    OLED_ShowString(0, linenum * 2, shownumstr, 16);
    memset(shownumstr, 0, 16);
    sprintf(shownumstr,"%s:%d", str, num);
    OLED_ShowString(0, linenum * 2, shownumstr, 16);
    linenum++;
    linenum = linenum % 4;
}
/*----------------------------------------------------------
函数描述： 显示LOGO：青鸟
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void showLOGO()
{
    OLED_Clear();
    OLED_DrawBMP(0,0,128,8,BMP2);
    showstatus = 1;
}
/*----------------------------------------------------------
函数描述： 显示菜单框架
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void showFRAME()
{
    OLED_Clear();//清除显示内容
    showstatus = 0;//重置显示状态 展示logo标志清除
    linenum = 0;//第一行显示菜单标题
    OLED_ShowString(0, linenum * 2, "******MENU******", 16);
    linenum = 3;//第四行显示提示信息
    OLED_ShowString(0, linenum * 2, "****************", 16);
}
/*----------------------------------------------------------
函数描述： 显示菜单
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void showMENU()
{
    showFRAME();
    linenum = 1;
    OLED_ShowString(0, linenum * 2, "*LOGO", 16);//第二行显示菜单选项
    OLED_ShowString(80, linenum * 2, "*CTRL", 16);//第二行显示菜单选项
    linenum = 2;
    OLED_ShowString(0, linenum * 2, "*DATA", 16);//第三行显示菜单选项
    linenum = 0;
}
/*----------------------------------------------------------
函数描述： 显示控制界面
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void showCTRL()
{
     linenum = 0;//第一行显示控制标题
    OLED_ShowString(0, linenum * 2, "******CTRL******", 16);
    linenum = 1;//第二行显示控制选项
    OLED_ShowString(0, linenum * 2, "*STOP", 16);
    OLED_ShowString(80, linenum * 2, "*BACK", 16);
    linenum = 2;//第三行显示提示信息
    OLED_ShowString(0, linenum * 2, "*RESUME", 16);
    linenum = 3;//第四行显示提示信息
    OLED_ShowString(0, linenum * 2, "****************", 16);
}
/*----------------------------------------------------------
函数描述： 显示初始化内容
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void oledInitprint()
{
    print2OLEDln("system init");
    delay_ms(1000);
    print2OLEDln("status update");
    delay_ms(1000);
    print2OLEDln("HeFei running...");
    delay_ms(1000);
    print2OLEDln("success");
    delay_ms(1000);
    OLED_Clear();
    print2OLEDln("showing logo");
    delay_ms(2000);
    showLOGO();
}
/*************************************************************************
LED控制
*************************************************************************/
/*----------------------------------------------------------
函数描述： 打开LED1
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_1_on(void){
    set_gpio_value(bd_gpio_group_e, bd_gpio_pin_3, 0);
}
/*----------------------------------------------------------
函数描述： 打开LED2
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_2_on(void){
    set_gpio_value(bd_gpio_group_e, bd_gpio_pin_4, 0);
}
/*----------------------------------------------------------
函数描述： 关闭LED1
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_1_off(void){
    set_gpio_value(bd_gpio_group_e, bd_gpio_pin_3, 1);
}
/*----------------------------------------------------------
函数描述： 翻转LED1
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_1_turn(void){
    if (GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_3) == Bit_SET) {
        GPIO_ResetBits(GPIOE, GPIO_Pin_3);  // 当前为高，设为低
    } else {
        GPIO_SetBits(GPIOE, GPIO_Pin_3);    // 当前为低，设为高
}
}
/*----------------------------------------------------------
函数描述： 关闭LED2
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_2_off(void){
    set_gpio_value(bd_gpio_group_e, bd_gpio_pin_4, 1);
}
/*----------------------------------------------------------
函数描述： 翻转LED2
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void Led_2_turn(void){
    if (GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_4) == Bit_SET) {
        GPIO_ResetBits(GPIOE, GPIO_Pin_4);  // 当前为高，设为低
    } else {
        GPIO_SetBits(GPIOE, GPIO_Pin_4);    // 当前为低，设为高
}
}
/*----------------------------------------------------------
函数描述： 碰到障碍物闪烁 通过修改i的值改变闪烁频率 每i个循环翻转一次
输入参数：类型： uint8_t
返回值： void
-----------------------------------------------------------*/
void Stop_Blink(uint8_t i){
    if (Move_Stop==1 && menual_stop==0)
        {
                if(fmeCnt%i==0)
                {
                    Led_1_turn();
                    Led_2_turn();
                }
        }
}
/*************************************************************************
485总线操作//超声波//温度
*************************************************************************/
/*----------------------------------------------------------
函数描述： 获取超声波数据
输入参数：类型： void
返回值： uint16
-----------------------------------------------------------*/
uint16_t get_distence(){
    uint16_t dist = 0;
    if(!xUSART.USART1_Busy)
    {
        USART1_RS485_RW_Opr(RADAR_ADDR,READ,0x0101,0x0001);//read distance data
    }
    delay_ms(100);
    if(xUSART.USART1_RX_FLAG)//wait for data
    {
        xUSART.USART1_RX_FLAG = 0;
        xUSART.USART1_Busy = 0;
        dist = RADAR_RX_DIST;
    }
    return dist;
}
/*----------------------------------------------------------
函数描述： 获取温度数据
输入参数：类型： void
返回值： uint16
-----------------------------------------------------------*/
uint16_t get_tempture(){
    uint16_t temp;
    if(!xUSART.USART1_Busy)
    {
        USART1_RS485_RW_Opr(RADAR_ADDR,READ,0x0102,0x0001);
    }
    delay_ms(100);
    if(xUSART.USART1_RX_FLAG)
    {
        xUSART.USART1_RX_FLAG = 0;
        xUSART.USART1_Busy = 0;
        temp = RADAR_RX_TEMP;
    }
    return temp;
}
/*************************************************************************
UART3串口操作
*************************************************************************/
/*----------------------------------------------------------
函数描述： 获取USART3串口接收数据，并于串口回传显示
输入参数：类型： void
返回值： uint8_t 有接收数据 1 无接收数据 0，数据存放位置USART3_RxBuffer
-----------------------------------------------------------*/
uint8_t getUART3data(void){
    if(USART3_RxFinished == 1){
        USART3_RxFinished = 0; //重置接收完成标志
        printf("uart3_rcv = %s\r\n", USART3_RxBuffer);//回传显示
        DMA_SetCurrDataCounter(DMA1_Channel3, USART3_RX_BUFFER_SIZE);//重置DMA数据计数器
        DMA_Cmd(DMA1_Channel3, ENABLE);//重新使能DMA传输
        return 1;//有接收数据
    }
    return 0;//无接收数据
}
/*----------------------------------------------------------
函数描述： 刷新USART3串口接收存储数组
输入参数：类型： void
返回值： void
-----------------------------------------------------------*/
void flashUART3(void){
    memset(USART3_RxBuffer, 0, USART3_RX_BUFFER_SIZE);
}


uint8_t chr2num(char c){
}
/*************************************************************************
w5500网络操作
*************************************************************************/